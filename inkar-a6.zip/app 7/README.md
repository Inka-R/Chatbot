# A6: Chatbot

## Your name

Inka Rzezinowska

## Your Glitch link

[my page](https://inkar-a1.glitch.me)

## Describe your bot's character

It is more or less just a cafe worker. It displays this by being overly friendly
and at some points, it even says to chill because it's only a minimum wage
worker. 

## How does the user know what to say to this bot How are you solving the blank slate problem?

This is definitely something I was wondering how to deal with as my first 
instinct when I see a chatbot is to just type anything into the text box.
When the person first walks into the cafe, you can type anything and the bot
will respond with let's take your order. Further interactions account for people
who want to write their own responses as well as those who utilize the chips. 

## How have your styled your page to best present this character? What scene or mood are you suggesting?

I definitely did not do anything fancy other than change the background to 
represent the cafe backdrop. I figured that this bot works long shifts and so it
doesn't want to be fancy. It doesn't have time to be fancy. I used to wear 
eyeliner to my opening cafe shifts and my eyes would literally burn. 

## Describe the first thing this bot can respond to. What is the expressive range of what you say in response?

The first thing that the bot can respond to is anything that the user types. 
Depending on what stage the conversation it is, a variety of things can happen. 
At the beginning, the bot just accepts whatever they said and continues to the
next part. When ordering, if the user types something, the bot says to please
not make it's life harder and to just use the given chips. Something similar 
happens in the paying stage: if the user types anything it says that it 
only accepts actual currency.

## Describe the second thing this bot can respond to

The money emoji! It was originally meant to just be used in the payment stage
but we can't really control when the user clicks it. As such, if used at the 
beginning, the bot responds with "please don't give me free money". It's a bot,
so unlike an actual human it won't take free money lol. Nevertheless, when used
in the proper way, the bot will respond with a variety of amounts. 

## Describe the third thing this bot can respond to

The waving emoji! This is a fairly standard response no matter what stage it is
used in: it's symbolizes the user leaving so it basically just says goodbye in
various ways. 

## Describe the fourth thing this bot can respond to

The shrug emoji! There's no way to insert an emoji for every possible emotion
there is, and so by pressing the shrug button it just gives you a random drink.
If used in the paying stage, the bot states that it only accepts actual 
currency.

## Describe the fifth thing this bot can respond to

The three emotion emojis: happy emoji, sad emoji, angry emoji. These basically
just give custom drink flavor options based on the emotion. Same as above: if
used in the paying stage the bot just rejects you. 

## What states does this bot move through? Is this a common social script? Why do the states connect like that?

So the bot has a few stages it goes through. The first is just origin, where it
starts. From here, it either goes to ordering or waiting. If you don't say 
anything, it asks if you're still there. So not really a typical social script
when conversing in real life, but is common in online conversations. There are
also options for paying and leaving. 

## In what ways does your bot obey or subvert the Gricean maxims

I'm pretty sure that my bot obeys the maxims. It doesn't say anything super
obscure but if the user says something unprecedented, it has a response for
it. 

## What 3 other bots did you look at? What was interesting, notable or useful about them?

I only looked at two other bots admitidely, and they were my peer reviews.
Nevertheless, they were both really interesting and reading through their
code helped me better understand how the parts work together. Michael Allen's
was particularly interesting due to it's very obscure navigation of the Gricean
Maxims. 

## List any resources (code, images, etc) you've used, and where you got them from

Starter code from Professor Compton. 

## List any help you got from classmates or websites, so that you can remember it for later

Peer reviews are helpful! Someone is usually done pretty early so if you're 
confused you can see how they did it! 
