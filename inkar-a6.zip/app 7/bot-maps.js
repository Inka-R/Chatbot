const BOT_MAPS = {
  
  cafeBot: {
  title: "Small cafe for the tired",
  botPfp: "☕",
  humanPfp: "🧑",
  chips: ["😊","😭", "😡","🤷", "💵", "👋"],

    states: {
      // The state we start at
      origin: {
        // When we enter the state say this
        onEnterSay: ["Hello! Welcome to the cafe!"],
        exits: [
          "'*'-> ordering 'Let me take your order.'",
          "wait:10 ->waiting 'Are you still here?'"
        ],
      },

      ordering: { 
        onEnterSay: ["How are you feeling today?"],
        exits: [
          "'👋' ->end 'Have a great day! Stop by again soon :)'",
          "'😊'-> paying 'Glad to hear it! I recommend a #happy# #drink# '",
          "'😭'-> paying 'Im sorry. I recommend a #sad# #drink#'",
          "'😡'-> paying 'Yea! You be angry >:(. I recommend a #mad# #drink#'",
          "'🤷'-> paying 'Ok! Try this: a #random# #drink#.'",
          "'💵'-> @ 'Please dont give me free money. Please try again :).'",
          "'*'-> @ 'I am a minimum wage worker please dont make this difficult. Please use the provided keys!'",
          "wait:10 ->waiting 'Are you still here?'"
              ],
      },
     
      paying: {
        onEnterSay: ["In that case, it will be #amount#"],
        exits: ["'💵' -> end 'Thank you! Enjoy your drink :D '",
               "'*' -> @ 'Im sorry. We only accept actual currency.'"],
      },
      
      waiting: {
        exits: ["'👋' ->end 'Have a great day! Stop by again soon :)'", "'*' -> ordering 'Alright!'"]
      },

      end: {
        onEnterSay: ["You leave the cafe. The end!"],
      },
    },

    grammar: {
      happy: ["sunny", "meme", "smiley", "warm"],
      sad: ["crying", "hug", "comforting", "familiar"],
      mad: ["Cheyenne pepper", "screaming", "punching","sour"],
      random: ["apple bottom jeans", "koala", "egg", "neon green"],
      drink: ["drip coffee", "latte", "red eye", "americano", "cappuccino", "machiatto", "affogatto"],
      amount: ["$2", "$3", "A smile!", "Whatever amount you can give", "It's free - don't tell anyone!"]
    },
  },
};
